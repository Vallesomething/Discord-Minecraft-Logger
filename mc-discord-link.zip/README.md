# MC-Discord Link (Advanced)
This project connects a Minecraft server with a Discord bot to sync player roles and log events.

## Features
- Minecraft to Discord: logs player join/leave
- Discord to Minecraft: sync Discord roles with LuckPerms groups
- Web API for communication

## Setup Instructions
See individual folders: `minecraft-plugin` and `discord-bot`
