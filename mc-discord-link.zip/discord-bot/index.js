const { Client, GatewayIntentBits } = require('discord.js');
const express = require('express');
const config = require('./config.json');

const app = express();
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

app.use(express.json());

app.post('/api/player-event', (req, res) => {
    const { player, type } = req.body;
    const channel = client.channels.cache.get(config.channelId);
    if (channel) channel.send(`Player **${player}** ${type === 'join' ? 'joined' : 'left'} the server.`);
    res.sendStatus(200);
});

client.once('ready', () => {
    console.log(`Bot ready: ${client.user.tag}`);
    app.listen(3000, () => console.log("API listening on port 3000"));
});

client.login(config.token);
