package com.example.linkplugin;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DiscordLinkPlugin extends JavaPlugin implements Listener {

    private final String endpoint = "http://localhost:3000/api/player-event";

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("DiscordLinkPlugin enabled");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        sendEvent(event.getPlayer().getName(), "join");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        sendEvent(event.getPlayer().getName(), "leave");
    }

    private void sendEvent(String player, String type) {
        try {
            URL url = new URL(endpoint);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);
            String json = String.format("{\"player\": \"%s\", \"type\": \"%s\"}", player, type);
            try (OutputStream os = con.getOutputStream()) {
                os.write(json.getBytes());
            }
            con.getInputStream().close();
        } catch (Exception e) {
            getLogger().warning("Failed to notify Discord bot: " + e.getMessage());
        }
    }
}
